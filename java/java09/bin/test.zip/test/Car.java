package test;

public class Car {
	
	String color;
	
	public void run() {
		System.out.println("차가 달리다");
	}
	
	

}
