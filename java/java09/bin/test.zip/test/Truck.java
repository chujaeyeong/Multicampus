package test;

public class Truck extends Car{ // color, run() 다 가지고 온다 !! 

	int weight;
	
	public void move() {
		System.out.println("물건을 운반하다.");
	}
}
