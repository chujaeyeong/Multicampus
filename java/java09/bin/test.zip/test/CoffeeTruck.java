package test;

public class CoffeeTruck extends Truck{
	
	int price;
	
	public void sell() {
		System.out.println("따뜻한 커피를 팝니다. ");
	}
	
}
